-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Nov 2022 pada 08.22
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.0.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_houseofnegative`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Single', 'single', '2022-11-14 00:04:32', '2022-11-14 00:04:32'),
(2, 'EP', 'ep', '2022-11-14 00:04:32', '2022-11-14 00:04:32'),
(3, 'Album', 'album', '2022-11-14 00:04:32', '2022-11-14 00:04:32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `events`
--

CREATE TABLE `events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `venue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `poster` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `events`
--

INSERT INTO `events` (`id`, `title`, `slug`, `venue`, `desc`, `date`, `poster`, `created_at`, `updated_at`) VALUES
(1, 'zxczxcz', 'zxczxcz', 'zxczxc', '<div>zxczxcaas daa sada</div>', '2022-11-16', 'img/event/9P0aVXIpXiegC1RMQomMUUZADE8LzEl9fbLp92F3.jpg', '2022-11-14 00:24:54', '2022-11-14 00:24:54'),
(2, 'Mair', 'mair', 'Pantai IU', '<div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos ipsum officiis cum veniam nemo. Dicta iusto impedit molestias cum ut totam, porro modi sed eos ipsum minus itaque, magni autem laborum nam quisquam reiciendis sit? Illum totam deserunt eligendi esse repellendus incidunt distinctio vitae. Rem laudantium beatae odit quae corrupti! Autem assumenda cupiditate tenetur odit commodi facilis ratione suscipit. Esse tempora voluptates explicabo iusto aliquid&nbsp;<br><br>consequuntur architecto assumenda doloremque? Libero earum odio repellat consequatur explicabo temporibus esse voluptas ipsa voluptatem fuga maxime, itaque mollitia officiis suscipit delectus labore voluptates, inventore asperiores debitis expedita! Quis, vitae eaque velit atque impedit voluptatum nisi est praesentium. Quasi, nesciunt quibusdam ducimus aspernatur perspiciatis dolores eaque nam ab impedit voluptates provident nemo adipisci magnam tenetur omnis in alias repudiandae officia doloremque voluptate corrupti hic. Error vitae nulla quibusdam beatae mollitia, magni ullam accusamus dolorum voluptatem&nbsp;<br><br>explicabo non, laborum maiores eaque voluptate consectetur provident deleniti aliquid similique! Provident ipsa cumque quae autem nam earum minima ea sapiente. Quos alias ea aliquid voluptatibus consequatur atque voluptatem corrupti. Reiciendis dolor, delectus repudiandae dolore perferendis molestias laborum illum ipsa atque quia sit ipsum accusamus qui exercitationem iure non minus ducimus sequi, assumenda deserunt repellat. Accusantium sapiente ullam soluta obcaecati?</div>', '2022-11-24', 'img/event/fQb6U06ZLzuYtKjWp8VvQrs8gP7vB4XB282Rf2eA.jpg', '2022-11-14 01:16:45', '2022-11-14 01:16:45'),
(3, 'Nogo fest', 'nogo-fest', 'Nogo', '<div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos ipsum officiis cum veniam nemo. Dicta iusto impedit molestias cum ut totam, porro modi sed eos ipsum minus itaque, magni autem laborum nam quisquam reiciendis sit? Illum totam deserunt eligendi esse repellendus incidunt distinctio vitae. Rem laudantium beatae odit quae corrupti! Autem assumenda cupiditate tenetur odit commodi facilis ratione suscipit. Esse tempora voluptates explicabo iusto aliquid&nbsp;<br><br>consequuntur architecto assumenda doloremque? Libero earum odio repellat consequatur explicabo temporibus esse voluptas ipsa voluptatem fuga maxime, itaque mollitia officiis suscipit delectus labore voluptates, inventore asperiores debitis expedita! Quis, vitae eaque velit atque impedit voluptatum nisi est praesentium. Quasi, nesciunt quibusdam ducimus aspernatur perspiciatis dolores eaque nam ab impedit voluptates provident nemo adipisci magnam tenetur omnis in alias repudiandae officia doloremque voluptate corrupti hic. Error vitae nulla&nbsp;<br><br>quibusdam beatae mollitia, magni ullam accusamus dolorum voluptatem explicabo non, laborum maiores eaque voluptate consectetur provident deleniti aliquid similique! Provident ipsa cumque quae autem nam earum minima ea sapiente. Quos alias ea aliquid voluptatibus consequatur atque voluptatem corrupti. Reiciendis dolor, delectus repudiandae dolore perferendis molestias laborum illum ipsa atque quia sit ipsum accusamus qui exercitationem iure non minus ducimus sequi, assumenda deserunt repellat. Accusantium sapiente ullam soluta obcaecati?</div>', '2022-12-03', 'img/event/nfy8RH2qqeoch5t5Q2IebyHIk7r00jx7K7q1d7XQ.jpg', '2022-11-14 01:17:27', '2022-11-14 01:17:27'),
(4, 'HCHCHCH', 'hchchch', 'basd', '<div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos ipsum officiis cum veniam nemo. Dicta iusto impedit molestias cum ut totam, porro modi sed eos ipsum minus itaque, magni autem laborum nam quisquam reiciendis sit? Illum totam deserunt eligendi esse repellendus incidunt distinctio vitae. Rem&nbsp;<br><br>laudantium beatae odit quae corrupti! Autem assumenda cupiditate tenetur odit commodi facilis ratione suscipit. Esse tempora voluptates explicabo iusto aliquid consequuntur architecto assumenda doloremque? Libero earum odio repellat consequatur explicabo temporibus esse voluptas ipsa voluptatem fuga maxime, itaque mollitia officiis suscipit delectus labore voluptates, inventore asperiores debitis expedita! Quis, vitae eaque velit atque impedit voluptatum nisi est&nbsp;<br><br>praesentium. Quasi, nesciunt quibusdam ducimus aspernatur perspiciatis dolores eaque nam ab impedit voluptates provident nemo adipisci magnam tenetur omnis in alias repudiandae officia doloremque voluptate corrupti hic. Error vitae nulla quibusdam beatae mollitia, magni ullam accusamus dolorum voluptatem explicabo non, laborum maiores eaque voluptate consectetur provident deleniti aliquid similique! Provident ipsa cumque quae autem nam earum minima ea&nbsp;<br><br>sapiente. Quos alias ea aliquid voluptatibus consequatur atque voluptatem corrupti. Reiciendis dolor, delectus repudiandae dolore perferendis molestias laborum illum ipsa atque quia sit ipsum accusamus qui exercitationem iure non minus ducimus sequi, assumenda deserunt repellat. Accusantium sapiente ullam soluta obcaecati?</div>', '2022-12-02', 'img/event/cAFo6NsEWHBMw7CvOV3DTjiQrGTjnD4faF63VjMq.jpg', '2022-11-14 01:21:52', '2022-11-14 01:21:52'),
(5, 'Soundrenalie', 'soundrenalie', 'asd asid ais', '<div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos ipsum officiis cum veniam nemo. Dicta iusto impedit molestias cum ut totam, porro modi sed eos ipsum minus itaque, magni autem laborum nam quisquam reiciendis sit? Illum totam deserunt eligendi esse repellendus incidunt distinctio vitae. Rem laudantium beatae odit quae corrupti! Autem assumenda cupiditate tenetur odit commodi facilis ratione suscipit. Esse tempora voluptates explicabo iusto aliquid&nbsp;<br><br>consequuntur architecto assumenda doloremque? Libero earum odio repellat consequatur explicabo temporibus esse voluptas ipsa voluptatem fuga maxime, itaque mollitia officiis suscipit delectus labore voluptates, inventore asperiores debitis expedita! Quis, vitae eaque velit atque impedit voluptatum nisi est praesentium. Quasi, nesciunt quibusdam ducimus aspernatur perspiciatis dolores eaque nam ab impedit voluptates provident nemo adipisci magnam tenetur omnis in alias repudiandae officia doloremque voluptate corrupti hic. Error vitae nulla quibusdam beatae mollitia, magni ullam accusamus dolorum voluptatem&nbsp;<br><br>explicabo non, laborum maiores eaque voluptate consectetur provident deleniti aliquid similique! Provident ipsa cumque quae autem nam earum minima ea sapiente. Quos alias ea aliquid voluptatibus consequatur atque voluptatem corrupti. Reiciendis dolor, delectus repudiandae dolore perferendis molestias laborum illum ipsa atque quia sit ipsum accusamus qui exercitationem iure non minus ducimus sequi, assumenda deserunt repellat. Accusantium sapiente ullam soluta obcaecati?</div>', '2022-11-30', 'img/event/VQZEwmBRPs4vxVcNfYxvLj9ApQNpbYgR6FZYpHvb.jpg', '2022-11-14 01:24:35', '2022-11-14 01:24:35'),
(6, 'Kosong kosong', 'kosong-kosong', 'Gaia Mall Pontianak', '<div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos ipsum officiis cum veniam nemo. Dicta iusto impedit molestias cum ut totam, porro modi sed eos ipsum minus itaque, magni autem laborum nam quisquam reiciendis sit? Illum totam deserunt eligendi esse repellendus incidunt distinctio vitae. Rem laudantium beatae odit quae corrupti! Autem assumenda cupiditate tenetur odit&nbsp;<br><br>commodi facilis ratione suscipit. Esse tempora voluptates explicabo iusto aliquid consequuntur architecto assumenda doloremque? Libero earum odio repellat consequatur explicabo temporibus esse voluptas ipsa voluptatem fuga maxime, itaque mollitia officiis suscipit delectus labore voluptates, inventore asperiores debitis expedita! Quis, vitae eaque velit atque impedit voluptatum nisi est praesentium. Quasi, nesciunt quibusdam ducimus aspernatur perspiciatis dolores eaque nam ab impedit voluptates provident nemo adipisci magnam tenetur omnis&nbsp;<br><br>in alias repudiandae officia doloremque voluptate corrupti hic. Error vitae nulla quibusdam beatae mollitia, magni ullam accusamus dolorum voluptatem explicabo non, laborum maiores eaque voluptate consectetur provident deleniti aliquid similique! Provident ipsa cumque quae autem nam earum minima ea sapiente. Quos alias ea aliquid voluptatibus consequatur atque voluptatem corrupti. Reiciendis dolor, delectus repudiandae dolore perferendis molestias laborum illum ipsa atque quia sit ipsum accusamus qui exercitationem iure non minus ducimus sequi, assumenda deserunt repellat. Accusantium sapiente ullam soluta obcaecati?</div>', '2022-12-10', 'img/event/oL8wtvnBi7AlpPdswDOK2K3uo8cscSu1TopJyiJS.jpg', '2022-11-14 01:27:59', '2022-11-14 01:27:59');

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `merchs`
--

CREATE TABLE `merchs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `merchs`
--

INSERT INTO `merchs` (`id`, `title`, `slug`, `desc`, `price`, `photo`, `created_at`, `updated_at`) VALUES
(1, 'Barasuara merch vol 1', 'barasuara-merch-vol-1', '<div>ashda sdausdahdba</div>', 170000, 'img/merch/sAbX9Y3xBvAwF0BLE581aC6cAu55XWpUMsutLL44.jpg', '2022-11-14 00:26:58', '2022-11-14 00:26:58'),
(2, 'Tumbler', 'tumbler', '<div>ajsdadd ajksdadajd akjdadj</div>', 70000, 'img/merch/bpyS7m2jSiGuyXalVlVu3MMtEJ7sz28jO7dSMlCT.jpg', '2022-11-14 00:55:09', '2022-11-14 00:55:09'),
(3, 'The Adams Vol 3', 'the-adams-vol-3', '<div>Tersedia dalam ukuran<br>s m l xl xxl</div>', 185000, 'img/merch/okmxrSdDqDn4NdeHNCWfhOkZUBNw9NLIR7oxvbBG.jpg', '2022-11-14 00:55:33', '2022-11-15 01:51:49'),
(5, 'Morfem putih', 'morfem-putih', '<div>asdas dvausda sbdiasdasdaana asd a sd<br>asjda sdasd<br>a alsdasd asd<br>asda sdjkaos<br>asd</div>', 180000, 'img/merch/eJVjlhynQGMmyZvth8TaLaHSXQbSKquFjtiewZqF.jpg', '2022-11-14 00:56:28', '2022-11-15 01:54:47'),
(6, 'Mocca MErch vol 1', 'mocca-merch-vol-1', '<div>Tersedia dalam size :<br>S M L XL XXL</div>', 165000, 'img/merch/iKECzDW41Pnx6u7lX9Gcmi1IeBKrAY06Ve5gpDKs.jpg', '2022-11-15 03:00:07', '2022-11-15 03:00:07');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_07_10_162408_create_releases_table', 1),
(6, '2022_07_10_175729_create_categories_table', 1),
(7, '2022_07_11_140701_create_talents_table', 1),
(8, '2022_09_05_161450_events', 1),
(9, '2022_11_13_150211_merchs', 1),
(10, '2022_11_14_061900_news', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `news`
--

CREATE TABLE `news` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `news`
--

INSERT INTO `news` (`id`, `title`, `slug`, `desc`, `excerpt`, `photo`, `created_at`, `updated_at`) VALUES
(1, 'konajsbd', 'konajsbd', '<div>asLorem ipsum dolor, sit amet consectetur adipisicing elit. Eligendi laboriosam dolorum dolore, cum fugiat beatae nostrum, odio obcaecati inventore quis voluptate. Consequatur vero modi excepturi fugit sunt exercitationem! Explicabo quae alias expedita molestias error! Voluptatum nisi ipsam qui id. Sed dignissimos, maiores dolorum repellendus architecto consectetur in, dolorem,&nbsp;<br><br>minima ad quam sit! Voluptatem quis similique quibusdam veritatis nam pariatur voluptatibus quia sunt corrupti magni ratione labore corporis nulla commodi provident, dolore maxime exercitationem perspiciatis ab molestiae. Dolor odio doloribus commodi ratione laborum. Officiis repellendus facere quia nobis aperiam tempore, sit quibusdam error possimus sed suscipit eum maxime iure.&nbsp;<br><br>Obcaecati soluta ut maxime, nam placeat sapiente deleniti nemo ab magnam asperiores eos excepturi architecto atque esse aut labore quam, similique sint? Officiis, ab quidem? Harum ut eaque debitis nesciunt! Quia assumenda temporibus dicta quas? Minus, accusamus facere? Suscipit impedit minima, mollitia enim quae aspernatur quas, cumque ipsam ullam hic perferendis. Ipsam, quae nostrum? Id, quae accusamus ullam quisquam dolore distinctio autem, illo obcaecati ipsum omnis magni repellat officia! Eveniet odio eligendi praesentium accusamus voluptatem, ea placeat, delectus dignissimos cum earum voluptatibus debitis consequuntur expedita asperiores dolores dicta recusandae laborum libero odit quia ab? Quaerat totam, rem suscipit architecto explicabo,&nbsp;<br><br>doloremque minima veniam error molestias nisi eius mollitia illum cum magnam, a voluptate consectetur at vel reprehenderit accusamus sed repudiandae temporibus? Eveniet aspernatur, harum iure ipsum mollitia in! Quasi itaque assumenda ipsam veniam eligendi doloribus exercitationem in autem, ducimus omnis dolorum sunt nobis ex. Ab numquam dolore ratione cupiditate in animi neque sunt culpa, deleniti voluptatibus itaque quasi eaque officia praesentium rem, nostrum rerum veniam omnis eum optio? Ad omnis pariatur nihil voluptates eum voluptatem distinctio est mollitia temporibus reiciendis! Officiis eum eaque consequuntur debitis in nobis facilis accusantium ad. Deleniti nemo iusto id excepturi asperiores laborum officia accusamus aut architecto maiores.</div>', '<div>asLorem ipsum dolor, sit amet consectetur adipisicing elit. Eligendi laboriosam dolorum dolore, cum fugiat beatae nostrum, odio obcaecati inventore quis voluptate. Consequatur vero modi excepturi fugit sunt exercitationem! Explicabo quae alias expedita molestias error! Voluptatum nisi ipsam qui</div>', 'img/news/bZeCX8MAmNfK95ncsd0qa6qggFEMNHLFp83wgFOe.jpg', '2022-11-14 00:37:10', '2022-11-14 00:37:10'),
(2, 'Synscronize', 'synscronize', '<div>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aliquid beatae magnam provident voluptas distinctio expedita, ipsum minus aspernatur porro ratione vitae modi unde nulla adipisci consequatur accusamus? Sapiente porro placeat culpa magnam facilis, nihil non enim consequatur sunt eaque doloremque necessitatibus voluptatem magni eos alias laudantium dignissimos? Tempora aperiam amet accusantium alias rem libero voluptatum reiciendis praesentium.&nbsp;<br><br>Totam enim dolorum obcaecati quo non nihil ratione, voluptate possimus quisquam magni laudantium architecto, reprehenderit voluptatibus debitis perferendis, neque impedit sed quae ipsum qui? Eaque sed odit nihil rem ab dolorum mollitia molestias accusamus deleniti inventore modi enim quas sunt, consequuntur minus ea excepturi temporibus? Animi impedit repellendus&nbsp;<br><br>expedita minima nostrum odio molestias voluptatum, alias repudiandae voluptate facilis nobis? Consequatur deleniti sint enim ipsum dolor laudantium officia ipsam ipsa perferendis omnis harum neque, cumque possimus? Velit aliquid maiores rem ipsam delectus voluptas, maxime provident autem ratione reprehenderit, nulla assumenda quas impedit numquam laborum?</div>', '<div>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aliquid beatae magnam provident voluptas distinctio expedita, ipsum minus aspernatur porro ratione vitae modi unde nulla adipisci consequatur accusamus? Sapiente porro placeat culpa magnam facilis, nihil non enim consequatur sunt eaque d</div>', 'img/news/DshUZBxpEPJBc8fBzUS7u7fVR4nSX8bfYY7g30An.jpg', '2022-11-14 00:42:37', '2022-11-14 00:42:37'),
(3, 'Soundrenaline 2022', 'soundrenaline-2022', '<div>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aliquid beatae magnam provident voluptas distinctio expedita, ipsum minus aspernatur porro ratione vitae modi unde nulla adipisci consequatur accusamus? Sapiente porro placeat culpa magnam facilis, nihil non enim consequatur sunt eaque doloremque&nbsp;<br><br>necessitatibus voluptatem magni eos alias laudantium dignissimos? Tempora aperiam amet accusantium alias rem libero voluptatum reiciendis praesentium. Totam enim dolorum obcaecati quo non nihil ratione, voluptate possimus quisquam magni laudantium architecto, reprehenderit voluptatibus debitis perferendis, neque impedit sed quae ipsum qui? Eaque sed odit nihil rem ab dolorum mollitia molestias accusamus deleniti inventore modi enim quas sunt,&nbsp;<br><br>consequuntur minus ea excepturi temporibus? Animi impedit repellendus expedita minima nostrum odio molestias voluptatum, alias repudiandae voluptate facilis nobis? Consequatur deleniti sint enim ipsum dolor laudantium officia ipsam ipsa perferendis omnis harum neque, cumque possimus? Velit aliquid maiores rem ipsam delectus voluptas, maxime provident autem ratione reprehenderit, nulla assumenda quas impedit numquam laborum?</div>', '<div>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aliquid beatae magnam provident voluptas distinctio expedita, ipsum minus aspernatur porro ratione vitae modi unde nulla adipisci consequatur accusamus? Sapiente porro placeat culpa magnam facilis, nihil non enim consequatur sunt eaque d</div>', 'img/news/ptfurjWCugpwuxBUy4zKT0PB8LKKiSk8zgrCsJy7.jpg', '2022-11-14 00:42:55', '2022-11-15 02:22:53');

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `releases`
--

CREATE TABLE `releases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `talent_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `talent_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `desc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `artwork` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `talent_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `releases`
--

INSERT INTO `releases` (`id`, `talent_name`, `title`, `slug`, `talent_id`, `category_id`, `desc`, `excerpt`, `email`, `instagram`, `artwork`, `talent_photo`, `created_at`, `updated_at`) VALUES
(2, 'Take it Easy', 'take it easy', 'take-it-easy', 2, 3, '<div>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Esse odit ad, pariatur laudantium suscipit et repellat distinctio! Debitis ea dolorem qui eligendi accusantium quidem, dicta deserunt. Commodi voluptatem, quis nisi odit repellat nemo eius deleniti, iure reprehenderit sit officia. Reprehenderit eum minus blanditiis ipsa dicta possimus aspernatur explicabo rem impedit sint! Aperiam obcaecati maiores quasi eos beatae reiciendis voluptatibus laboriosam! Labore totam asperiores alias quo, pariatur amet, assumenda&nbsp;<br><br>eligendi cumque quibusdam excepturi minus autem optio ex quisquam architecto eaque porro ratione odit praesentium? Rem, porro? Eum, nostrum quo sed odit dolores quidem amet magni iusto doloremque error sunt? Ducimus, praesentium vero earum placeat deserunt iusto accusamus nihil quam soluta quos voluptatem rerum voluptatibus architecto obcaecati reprehenderit repellendus perspiciatis explicabo blanditiis id. Consequuntur modi iusto, maiores deleniti placeat odit est dolor, ducimus quaerat esse voluptas! Dolorem beatae mollitia ea a quis natus nesciunt officia repudiandae vero perferendis minus ad facilis nihil maiores ipsum earum&nbsp;<br><br>iure, ducimus corrupti quod, modi est necessitatibus veniam fugiat! Sint, nemo delectus. Officiis eligendi qui odio magni eum doloremque, veniam, quod accusantium officia et nihil. Voluptatibus reprehenderit nostrum aperiam repudiandae officia porro quo ab temporibus. Placeat, pariatur qui autem exercitationem cumque deserunt suscipit consequatur neque laboriosam, at aspernatur? Laudantium laborum, similique minus sit doloribus rem corporis, itaque modi, libero reiciendis molestiae vitae corrupti unde dolorem earum quidem vel mollitia? Rem beatae eius animi dolore quis, libero nulla, odio culpa, eaque doloribus placeat quod voluptatem nam quisquam omnis! Corporis blanditiis porro voluptates officia mollitia nihil possimus omnis libero cum incidunt. Cupiditate ex non alias asperiores perferendis voluptatem reiciendis cumque quam reprehenderit, vitae magnam exercitationem optio quis tempora dolore tempore ut, dolorum autem qui eum a! At, odit possimus. Voluptates nesciunt, provident minima magnam quae neque qui,&nbsp;<br><br>recusandae doloremque magni, facere est nobis. Exercitationem enim inventore soluta, voluptatem sit iure iusto quod perferendis necessitatibus ratione, laborum dolores corporis explicabo odit pariatur quis quo, minima quia quas. Accusantium eligendi sequi vero rerum numquam quia nisi maxime repellendus, id voluptatibus, praesentium delectus quas. Doloremque ratione soluta enim eos voluptatibus iste voluptates cupiditate, voluptatum quidem sit necessitatibus alias aperiam quas veritatis! Illo, amet neque debitis totam nobis architecto praesentium quas nihil repudiandae! Culpa amet nostrum iusto pariatur voluptatibus eum id vero quaerat quibusdam dolorum in quas et expedita, molestiae, qui quo ipsa sunt ea quasi placeat rerum facere iure! Sunt est, harum, doloremque optio impedit, sequi iusto exercitationem modi dicta fuga ad?</div>', '<div>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Esse odit ad, pariatur laudantium suscipit et repellat distinctio! Debitis ea dolorem qui eligendi accusantium quidem, dicta deserunt. Commodi voluptatem, quis nisi odit repellat nemo eius deleniti, iure reprehenderit sit officia. Repreh</div>', 'amirullazmi0@gmail.com', 'takeiteasygram', 'img/artwork/lttkpvkuicWBuPWjRAZVfEFK4nb2xXOfD7d2MALN.webp', 'img/talent/c30aXRkWfF1pzsq8v3n98lBX2XzahL2QW6Qb265g.webp', '2022-11-14 00:58:05', '2022-11-14 00:58:05'),
(3, 'Two Phi', 'two phi', 'two-phi', 3, 2, '<div>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Esse odit ad, pariatur laudantium suscipit et repellat distinctio! Debitis ea dolorem qui eligendi accusantium quidem, dicta deserunt. Commodi voluptatem, quis nisi odit repellat nemo eius deleniti, iure reprehenderit sit officia. Reprehenderit eum minus blanditiis ipsa dicta possimus aspernatur explicabo rem impedit sint! Aperiam obcaecati maiores quasi eos beatae reiciendis voluptatibus laboriosam! Labore totam asperiores alias quo, pariatur amet, assumenda&nbsp;<br><br>eligendi cumque quibusdam excepturi minus autem optio ex quisquam architecto eaque porro ratione odit praesentium? Rem, porro? Eum, nostrum quo sed odit dolores quidem amet magni iusto doloremque error sunt? Ducimus, praesentium vero earum placeat deserunt iusto accusamus nihil quam soluta quos voluptatem rerum voluptatibus architecto obcaecati reprehenderit repellendus perspiciatis explicabo blanditiis id. Consequuntur modi iusto, maiores deleniti placeat odit est dolor, ducimus quaerat esse voluptas! Dolorem beatae mollitia ea a quis natus nesciunt officia repudiandae vero perferendis minus ad facilis nihil maiores ipsum earum iure, ducimus corrupti quod, modi est necessitatibus veniam fugiat! Sint, nemo delectus. Officiis eligendi qui odio magni eum doloremque, veniam, quod accusantium officia et nihil. Voluptatibus reprehenderit nostrum aperiam repudiandae officia porro quo ab temporibus. Placeat, pariatur qui autem exercitationem cumque deserunt suscipit consequatur neque laboriosam, at aspernatur? Laudantium laborum, similique minus sit doloribus rem corporis, itaque modi, libero reiciendis molestiae vitae corrupti unde dolorem&nbsp;<br><br>earum quidem vel mollitia? Rem beatae eius animi dolore quis, libero nulla, odio culpa, eaque doloribus placeat quod voluptatem nam quisquam omnis! Corporis blanditiis porro voluptates officia mollitia nihil possimus omnis libero cum incidunt. Cupiditate ex non alias asperiores perferendis voluptatem reiciendis cumque quam reprehenderit, vitae magnam exercitationem optio quis tempora dolore tempore ut, dolorum autem qui eum a! At, odit possimus. Voluptates nesciunt, provident minima magnam quae neque qui, recusandae doloremque magni, facere est nobis. Exercitationem enim inventore soluta, voluptatem sit iure iusto quod perferendis necessitatibus ratione, laborum dolores corporis explicabo odit pariatur quis quo, minima quia quas. Accusantium eligendi sequi vero&nbsp;<br><br>rerum numquam quia nisi maxime repellendus, id voluptatibus, praesentium delectus quas. Doloremque ratione soluta enim eos voluptatibus iste voluptates cupiditate, voluptatum quidem sit necessitatibus alias aperiam quas veritatis! Illo, amet neque debitis totam nobis architecto praesentium quas nihil repudiandae! Culpa amet nostrum iusto pariatur voluptatibus eum id vero quaerat quibusdam dolorum in quas et expedita, molestiae, qui quo ipsa sunt ea quasi placeat rerum facere iure! Sunt est, harum, doloremque optio impedit, sequi iusto exercitationem modi dicta fuga ad?</div>', '<div>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Esse odit ad, pariatur laudantium suscipit et repellat distinctio! Debitis ea dolorem qui eligendi accusantium quidem, dicta deserunt. Commodi voluptatem, quis nisi odit repellat nemo eius deleniti, iure reprehenderit sit officia. Repreh</div>', 'asda@ajashajsihsd.com', 'amrllazmi', 'img/artwork/zr6yncJhW1vvbkqNKSFIyoWHvyIic4QgW9KNOrDl.jpg', 'img/talent/64xMqwKMB9WYJWvvVCAkUcpNOzF8adTcBDXJ6sYv.jpg', '2022-11-14 00:58:47', '2022-11-14 00:58:47'),
(4, 'Public Noise', 'Boombag', 'boombag', 3, 3, '<div>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Esse odit ad, pariatur laudantium suscipit et repellat distinctio! Debitis ea dolorem qui eligendi accusantium quidem, dicta deserunt. Commodi voluptatem, quis nisi odit repellat nemo eius deleniti, iure reprehenderit sit officia. Reprehenderit eum minus blanditiis ipsa dicta possimus aspernatur explicabo rem impedit sint! Aperiam obcaecati maiores quasi eos beatae reiciendis voluptatibus laboriosam! Labore totam asperiores alias quo, pariatur amet, assumenda eligendi cumque quibusdam excepturi minus autem optio ex quisquam architecto eaque porro ratione odit praesentium? Rem, porro?&nbsp;<br><br>Eum, nostrum quo sed odit dolores quidem amet magni iusto doloremque error sunt? Ducimus, praesentium vero earum placeat deserunt iusto accusamus nihil quam soluta quos voluptatem rerum voluptatibus architecto obcaecati reprehenderit repellendus perspiciatis explicabo blanditiis id. Consequuntur modi iusto, maiores deleniti placeat odit est dolor, ducimus quaerat esse voluptas! Dolorem beatae mollitia ea a quis natus nesciunt officia repudiandae vero perferendis minus ad facilis nihil maiores ipsum earum iure, ducimus corrupti quod, modi est necessitatibus veniam fugiat! Sint, nemo delectus. Officiis eligendi qui odio magni eum doloremque, veniam, quod accusantium officia et nihil. Voluptatibus reprehenderit nostrum aperiam repudiandae officia porro quo ab&nbsp;<br><br>temporibus. Placeat, pariatur qui autem exercitationem cumque deserunt suscipit consequatur neque laboriosam, at aspernatur? Laudantium laborum, similique minus sit doloribus rem corporis, itaque modi, libero reiciendis molestiae vitae corrupti unde dolorem earum quidem vel mollitia? Rem beatae eius animi dolore quis, libero nulla, odio culpa, eaque doloribus placeat quod voluptatem nam quisquam omnis! Corporis blanditiis porro voluptates officia mollitia nihil possimus omnis libero cum incidunt. Cupiditate ex non alias asperiores perferendis voluptatem reiciendis cumque quam reprehenderit, vitae magnam exercitationem optio quis tempora dolore tempore ut, dolorum autem qui eum a! At, odit possimus. Voluptates nesciunt, provident minima magnam quae neque qui, recusandae doloremque magni, facere est nobis. Exercitationem enim inventore soluta, voluptatem sit iure iusto quod perferendis necessitatibus ratione, laborum dolores corporis explicabo odit pariatur quis quo, minima quia quas. Accusantium eligendi sequi vero&nbsp;<br><br>rerum numquam quia nisi maxime repellendus, id voluptatibus, praesentium delectus quas. Doloremque ratione soluta enim eos voluptatibus iste voluptates cupiditate, voluptatum quidem sit necessitatibus alias aperiam quas veritatis! Illo, amet neque debitis totam nobis architecto praesentium quas nihil repudiandae! Culpa amet nostrum iusto pariatur voluptatibus eum id vero quaerat quibusdam dolorum in quas et expedita, molestiae, qui quo ipsa sunt ea quasi placeat rerum facere iure! Sunt est, harum, doloremque optio impedit, sequi iusto exercitationem modi dicta fuga ad?</div>', '<div>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Esse odit ad, pariatur laudantium suscipit et repellat distinctio! Debitis ea dolorem qui eligendi accusantium quidem, dicta deserunt. Commodi voluptatem, quis nisi odit repellat nemo eius deleniti, iure reprehenderit sit officia. Repreh</div>', 'bomarizkyadi48@gmail.com', 'amrllazmi', 'img/artwork/hQlPcMjbdgy9zjMAOGO7SjBXIRqtzX4LPtoBfkX9.jpg', 'img/talent/oEcg6c9dG8tZgHQkY5ruyo4YezODBB10tKDNwhzN.jpg', '2022-11-14 00:59:58', '2022-11-14 22:09:51');

-- --------------------------------------------------------

--
-- Struktur dari tabel `talents`
--

CREATE TABLE `talents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `talents`
--

INSERT INTO `talents` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Solo', 'solo', '2022-11-14 00:04:32', '2022-11-14 00:04:32'),
(2, 'Group Band', 'group-band', '2022-11-14 00:04:32', '2022-11-14 00:04:32'),
(3, 'Group Rap', 'group-rap', '2022-11-14 00:04:32', '2022-11-14 00:04:32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Amirull Azmi', 'Amirooo', 'amirullazmi0@gmail.com', '2022-11-14 00:04:32', '$2y$10$WAD4XyPUPuH3/1Zn3jbfruwi4DjPSIAjmqOLIBbW9cJgTzi0cHyhq', '7V7I7L8M38', '2022-11-14 00:04:32', '2022-11-14 00:04:32');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_name_unique` (`name`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indeks untuk tabel `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `events_slug_unique` (`slug`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `merchs`
--
ALTER TABLE `merchs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `merchs_slug_unique` (`slug`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `news_slug_unique` (`slug`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indeks untuk tabel `releases`
--
ALTER TABLE `releases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `releases_slug_unique` (`slug`);

--
-- Indeks untuk tabel `talents`
--
ALTER TABLE `talents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `talents_name_unique` (`name`),
  ADD UNIQUE KEY `talents_slug_unique` (`slug`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `events`
--
ALTER TABLE `events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `merchs`
--
ALTER TABLE `merchs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `news`
--
ALTER TABLE `news`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `releases`
--
ALTER TABLE `releases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `talents`
--
ALTER TABLE `talents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
