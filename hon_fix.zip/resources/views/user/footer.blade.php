<footer class="stiky-bottom">
    <div class="footer-top">
        <div class="row justify-content-center text-white-50">
            <div class="col-4 text-center">
                <a class="text-white-50" href="">
                    <span class="material-symbols-outlined">
                        mail
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="footer-bot">
        <div class="row justify-content-center text-white-50">
            <small class="text-center">
                <a class="text-white-50 text-decoration-none" href="">amirullazmi0@gmail.com</a>
            </small>
        </div>
    </div>
</footer>