

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="talent">
        <div class="pop mb-3">
            <h1 class="text-center">DAFT TALENT</h1>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <a class="btn btn-wow mt-3 mb-3" href="">Add Talent</a>
                        <div class="table-responsive">
                            <table class="table table-bordered ">
                                <thead class="text-center fw-bold">
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">TALENT</th>
                                        <th scope="col">PHOTO</th>
                                        <th scope="col">ACTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="text-center align-middle">
                                        <th scope="row">1</th>
                                        <td>Twophi</td>
                                        <td><img class="img-fluid img-talent" src="/img/talent/twophi.jpg" alt=""></td>
                                        <td> <a class="btn btn-sm btn-detail" href="">Detail</a>
                                            <a class="btn btn-sm btn-edit" href="">Edit</a>
                                            <a class="btn btn-sm btn-delete" href="">Delete</a>
                                        </td>
                                    </tr>
                                    <tr class="text-center align-middle">
                                        <th scope="row">2</th>
                                        <td>Twophi</td>
                                        <td><img class="img-fluid img-talent" src="/img/talent/twophi.jpg" alt=""></td>
                                        <td>
                                            <a class="btn btn-sm btn-detail" href="">Detail</a>
                                            <a class="btn btn-sm btn-edit" href="">Edit</a>
                                            <a class="btn btn-sm btn-delete" href="">Delete</a>
                                        </td>
                                    </tr>
                                    <tr class="text-center align-middle">
                                        <th scope="row">3</th>
                                        <td>Twophi</td>
                                        <td><img class="img-fluid img-talent" src="/img/talent/twophi.jpg" alt=""></td>
                                        <td>
                                            <a class="btn btn-sm btn-detail" href="">Detail</a>
                                            <a class="btn btn-sm btn-edit" href="">Edit</a>
                                            <a class="btn btn-sm btn-delete" href="">Delete</a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Laravel\hon_fix\resources\views//admin/v_talent.blade.php ENDPATH**/ ?>