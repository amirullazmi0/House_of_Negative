

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="event">
        <div class="pop mb-3 shadow-sm border">
            <h1 class="text-center">DAFT EVENT</h1>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card shadow-sm border">
                    <div class="card-body">
                        <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= session('success'); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php endif; ?>
                        <a class="btn btn-wow mt-3 mb-3" href="/admin/event/create">Add Event</a>
                        <div class="row">
                            <?php if($event->count()): ?>
                            <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4">
                                <div class="card shadow-sm border mb-4">
                                    <div class="text-center">
                                        <div class="text-center">
                                            <?php if($event->poster): ?>
                                            <img class="img-fluid img-event" src="<?= asset('storage/' . $event->poster); ?>" alt="">
                                            <?php else: ?>
                                            <img class="img-fluid img-event" src="/img/default.jpg" alt="">
                                            <?php endif; ?>
                                            <h4 class="text-uppercase mt-2 mb-0 fw-bold"><?= $event->title; ?></h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-center">
                                            <a class="btn btn-sm btn-detail m-1" href="/admin/event/<?= $event->slug; ?>">
                                                <span class="material-symbols-outlined">
                                                    sticky_note_2
                                                </span>
                                            </a>
                                            <a class="btn btn-sm btn-edit m-1" href="/admin/event/<?= $event->slug; ?>/edit">
                                                <span class="material-symbols-outlined">
                                                    edit
                                                </span>
                                            </a>
                                            <a class="btn btn-sm btn-delete m-1" onclick="return confirm('Are you sure to delete ?')" href="/admin/event/delete/<?= $event->slug; ?>">
                                                <span class="material-symbols-outlined">
                                                    delete
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <h3 class="text-center mt-5 mb-5">DATA NOT FOUND</h3>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Laravel\hon_fix\resources\views//admin/v_event.blade.php ENDPATH**/ ?>