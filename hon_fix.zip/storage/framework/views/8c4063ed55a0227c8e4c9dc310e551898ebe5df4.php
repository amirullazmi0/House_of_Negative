

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="category">
        <div class="pop mb-3 border shadow-sm">
            <h1>ALL CATEGORY</h1>
        </div>
        <div class="row d-flex justify-content-center">
            <!-- TYPE CATEGORY -->
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6">
                <a href="/admin/category/<?= $category->slug; ?>">
                    <div class="card border shadow-sm">
                        <div class="card-body">
                            <h2 class="text-center"><?= $category->name; ?></h2>
                            <p style="background-color: rgb(189, 8, 8);color: white;border-color: transparent;border-radius: 50px;" class="text-center d-grid gap-2 col-6 mx-auto p-3">
                                <?= $category->release->count(); ?>
                            </p>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- TYPE TALENT -->
            <?php $__currentLoopData = $talent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $talent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6">
                <a href="/admin/talent/<?= $talent->slug; ?>">
                    <div class="card border shadow-sm">
                        <div class="card-body">
                            <h2 class="text-center"><?= $talent->name; ?></h2>
                            <p style="background-color: rgb(189, 8, 8);color: white;border-color: transparent;border-radius: 50px;" class="text-center d-grid gap-2 col-6 mx-auto p-3">
                                <?= $talent->release->count(); ?>
                            </p>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Laravel\hon_fix\resources\views//admin/v_category.blade.php ENDPATH**/ ?>