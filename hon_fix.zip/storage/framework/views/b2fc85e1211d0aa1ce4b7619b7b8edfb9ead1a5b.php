

<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<div class="container">
    <div class="home">
        <div class="pop mb-3 border shadow-sm">
            <h1 class="text-uppercase">WELCOME <?php echo e(auth()->user()->username); ?> !!!</h1>
        </div>
        <div class="row d-flex justify-content-center">
            <div class="col-6">
                <a href="/admin/release">
                    <div class="card shadow-sm border">
                        <div class="card-body">
                            <h2 class="text-center">RELEASE</h2>
                            <p style="background-color: rgb(189, 8, 8);color: white;border-color: transparent;border-radius: 50px;" class="text-center d-grid col-6 mx-auto p-3">
                                <?php echo e($j_release); ?>

                            </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6">
                <a href="/admin/event">
                    <div class="card shadow-sm border">
                        <div class="card-body">
                            <h2 class="text-center">EVENT</h2>
                            <p style="background-color: rgb(189, 8, 8);color: white;border-color: transparent;border-radius: 50px;" class="text-center d-grid col-6 mx-auto p-3">
                                <?php echo e($j_event); ?>

                            </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6">
                <a href="/admin/merch">
                    <div class="card shadow-sm border">
                        <div class="card-body">
                            <h2 class="text-center">MERCH</h2>
                            <p style="background-color: rgb(189, 8, 8);color: white;border-color: transparent;border-radius: 50px;" class="text-center d-grid col-6 mx-auto p-3">
                                <?php echo e($j_merch); ?>

                            </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6"> 
                <a href="/admin/news">
                    <div class="card shadow-sm border">
                        <div class="card-body">
                            <h2 class="text-center">NEWS</h2>
                            <p style="background-color: rgb(189, 8, 8);color: white;border-color: transparent;border-radius: 50px;" class="text-center d-grid col-6 mx-auto p-3">
                                <?php echo e($j_news); ?>

                            </p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Laravel\hon_fix\resources\views//admin/v_home.blade.php ENDPATH**/ ?>