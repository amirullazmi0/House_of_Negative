

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="about">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="pop mb-3 border shadow-sm">
                    <h1 class="text-center">ABOUT HON</h1>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card border shadow-sm mb-5">
                    <div class="card-body">
                        <form action="">
                            <div class="row">
                                <div class="col-lg-6 mb-3">
                                    <label class="form-label" for="title">Name</label>
                                    <input class="form-control form-control-sm" type="text" name="title" id="title" autofocus required>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="form-label" for="title">Instagram</label>
                                    <input class="form-control form-control-sm" type="text" name="title" id="title" autofocus>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="form-label" for="title">Facebook</label>
                                    <input class="form-control form-control-sm" type="text" name="title" id="title" autofocus>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="form-label" for="title">email</label>
                                    <input class="form-control form-control-sm" type="text" name="title" id="title" autofocus>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <label class="form-label" for="desc">Description</label>
                                    <form …>
                                        <input class="<?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="desc" type="hidden" name="desc">
                                        <trix-editor class="form-control <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" input="desc"></trix-editor>
                                    </form>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="artwork" for="poster">Logo</label>
                                    <img class="img-preview img-fluid" alt="">
                                    <input class="form-control form-control-sm" type="file" id="poster" name="poster" onchange="previewImage">
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="artwork" for="poster">Foto</label>
                                    <img class="img-preview img-fluid" alt="">
                                    <input class="form-control form-control-sm" type="file" id="poster" name="poster" onchange="previewImage">
                                </div>
                                <hr class="mt-3">
                                <div class="d-grid gap-2 col-4 p-3 mx-auto">
                                    <button class="btn btn-detail btn-sm fw-bold text-uppercase p-2" type="submit">Update About</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Laravel\hon_fix\resources\views//admin/v_about.blade.php ENDPATH**/ ?>