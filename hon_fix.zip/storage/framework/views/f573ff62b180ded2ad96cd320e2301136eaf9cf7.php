<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/admin.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
</head>


<body>
    <div class="release">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-4 ">
                    <div class="card">
                        <div class="card-body">
                            <img class="img-fluid mx-auto d-block mb-4" src="/img/hon-logo.jpg" alt="" style="max-height: 100px;">
                            <h5 class="text-center mb-5">LOGIN ADMIN</h5>
                            <form action="">
                                <div class="input-group input-group-sm mb-3">
                                    <span class="input-group-text" id="inputGroup-sizing-sm">
                                        <span class="material-symbols-outlined">
                                            person
                                        </span>
                                    </span>
                                    <input type="text" class="form-control" placeholder="Username">
                                </div>
                                <div class="input-group input-group-sm mb-5">
                                    <span class="input-group-text" id="inputGroup-sizing-sm">
                                        <span class="material-symbols-outlined">
                                            lock
                                        </span>
                                    </span>
                                    <input type="password" class="form-control" placeholder="Password">
                                </div>
                                <button class="btn btn-delete d-block col-6 mx-auto" type="submit">Login</button>
                                <hr>
                                <!-- <small class="text-center">
                                    <a class="text-decoration-none text-warnin" href="">Back to Home</a>
                                </small> -->
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>

</html><?php /**PATH D:\Project Laravel\hon_fix\resources\views//login/v_login.blade.php ENDPATH**/ ?>